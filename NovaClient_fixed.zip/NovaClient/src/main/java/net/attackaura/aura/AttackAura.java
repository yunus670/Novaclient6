package net.attackaura.aura;

import com.nova.client.rotation.RotationManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.hit.HitResult;

import java.util.Comparator;
import java.util.List;
import java.util.Random;

public final class AttackAura {

    private static final float   REACH             = 3.2f;
    private static final float   FOV               = 180f;
    private static final float   SMOOTH_SPEED      = 0.42f;
    private static final float   SENSITIVITY       = 0.85f;
    private static final float   JITTER_AMOUNT     = 0.09f;
    private static final float   JITTER_FREQ       = 0.18f;
    private static final float   COOLDOWN_THRESH   = 0.95f;
    private static final int     SWITCH_LOCK_TICKS = 6;
    private static final float   PREDICT_TICKS     = 0.85f;
    private static final boolean CHECK_VISIBILITY  = true;
    private static final boolean SKIP_TEAM         = true;

    private static float        silentYaw     = 0f;
    private static float        silentPitch   = 0f;
    private static boolean      silentActive  = false;
    private static boolean      rotInit       = false;
    private static LivingEntity currentTarget = null;
    private static int          targetLockTick = 0;
    private static int          lastAttackTick = Integer.MIN_VALUE;
    private static final Random RNG            = new Random();
    private static long         jitterTick     = 0;
    private static float        lastDeltaYaw   = 0f;
    private static float        lastDeltaPitch = 0f;

    public static LivingEntity getTarget() { return currentTarget; }

    public static void clearTarget() {
        currentTarget  = null;
        silentActive   = false;
        rotInit        = false;
        lastAttackTick = Integer.MIN_VALUE;
        targetLockTick = 0;
        RotationManager.clear();
        RotationManager.clearMove();
    }

    public static void onClientTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) {
            clearTarget(); return;
        }

        LivingEntity target = selectTarget(mc);
        currentTarget = target;
        if (target == null) { clearTarget(); return; }

        Vec3d predictedPos = predictPosition(target, PREDICT_TICKS);
        Vec3d eyes         = mc.player.getEyePos();
        Vec3d diff         = predictedPos.subtract(eyes);

        float targetYaw   = (float) Math.toDegrees(Math.atan2(-diff.x, diff.z));
        float targetPitch = MathHelper.clamp(
                (float) -Math.toDegrees(Math.atan2(diff.y,
                        Math.sqrt(diff.x * diff.x + diff.z * diff.z))),
                -90f, 90f);

        if (!rotInit) {
            silentYaw   = mc.player.getYaw();
            silentPitch = mc.player.getPitch();
            rotInit     = true;
        }

        float rawDY = gcdFix(MathHelper.wrapDegrees(targetYaw   - silentYaw),   lastDeltaYaw);
        float rawDP = gcdFix(MathHelper.wrapDegrees(targetPitch - silentPitch),  lastDeltaPitch);

        float jY = jitter(jitterTick,     JITTER_AMOUNT,        JITTER_FREQ);
        float jP = jitter(jitterTick + 7, JITTER_AMOUNT * 0.6f, JITTER_FREQ);
        jitterTick++;

        float stepY = rawDY * SMOOTH_SPEED + jY;
        float stepP = rawDP * SMOOTH_SPEED + jP;

        silentYaw    = silentYaw + stepY;
        silentPitch  = MathHelper.clamp(silentPitch + stepP, -90f, 90f);
        lastDeltaYaw   = stepY;
        lastDeltaPitch = stepP;

        silentActive = true;
        RotationManager.set(silentYaw, silentPitch);
        RotationManager.setMove(mc.player.getYaw(), true);
    }

    public static void onPostMovementPackets(MinecraftClient mc) {
        if (!silentActive || currentTarget == null) return;
        if (mc.player == null || mc.interactionManager == null) return;

        LivingEntity target = currentTarget;
        if (!target.isAlive() || target.isRemoved()) return;

        int tick = mc.player.age;
        if (tick == lastAttackTick) return;
        if (mc.player.getAttackCooldownProgress(0.5f) < COOLDOWN_THRESH) return;
        if (!aimClose(targetYaw(mc, currentTarget), targetPitch(mc, currentTarget))) return;

        lastAttackTick = tick;
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    private static LivingEntity selectTarget(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        Vec3d eyes = player.getEyePos();

        if (currentTarget != null && currentTarget.isAlive()
                && !currentTarget.isRemoved()
                && bbReach(player, currentTarget) <= REACH
                && player.age - targetLockTick < SWITCH_LOCK_TICKS) {
            return currentTarget;
        }

        List<LivingEntity> candidates = mc.world.getEntitiesByClass(
                LivingEntity.class,
                player.getBoundingBox().expand(REACH + 1.0),
                e -> e != player && e.isAlive() && !e.isRemoved()
        );

        Vec3d look = Vec3d.fromPolar(player.getPitch(), player.getYaw()).normalize();

        LivingEntity best = candidates.stream()
                .filter(e -> !(e instanceof PlayerEntity p) || !SKIP_TEAM || !player.isTeammate(p))
                .filter(e -> bbReach(player, e) <= REACH)
                .filter(e -> inFov(eyes, look, e))
                .filter(e -> !CHECK_VISIBILITY || visible(mc, eyes, e))
                .min(Comparator.comparingDouble(e -> bbReach(player, e)))
                .orElse(null);

        if (best != null && best != currentTarget) targetLockTick = mc.player.age;
        return best;
    }

    private static float bbReach(ClientPlayerEntity player, LivingEntity target) {
        Vec3d eyes = player.getEyePos();
        Box bb = target.getBoundingBox();
        double x = MathHelper.clamp(eyes.x, bb.minX, bb.maxX) - eyes.x;
        double y = MathHelper.clamp(eyes.y, bb.minY, bb.maxY) - eyes.y;
        double z = MathHelper.clamp(eyes.z, bb.minZ, bb.maxZ) - eyes.z;
        return (float) Math.sqrt(x * x + y * y + z * z);
    }

    private static boolean inFov(Vec3d eyes, Vec3d look, LivingEntity e) {
        if (FOV >= 360f) return true;
        Vec3d toTarget = e.getBoundingBox().getCenter().subtract(eyes).normalize();
        double dot = MathHelper.clamp(look.dotProduct(toTarget), -1.0, 1.0);
        return Math.toDegrees(Math.acos(dot)) <= FOV / 2.0;
    }

    private static boolean visible(MinecraftClient mc, Vec3d eyes, LivingEntity e) {
        Vec3d center = e.getBoundingBox().getCenter();
        var hit = mc.world.raycast(new RaycastContext(
                eyes, center,
                RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE,
                mc.player
        ));
        return hit.getType() == HitResult.Type.MISS;
    }

    private static Vec3d predictPosition(LivingEntity target, float ticks) {
        return target.getBoundingBox().getCenter().add(target.getVelocity().multiply(ticks));
    }

    private static float gcdFix(float delta, float lastDelta) {
        float gcd = calcGcd(Math.abs(lastDelta), 0.15f);
        if (gcd < 0.01f) return delta;
        float sensitivity = SENSITIVITY * SENSITIVITY * 8f * 0.15f;
        if (sensitivity < 0.0001f) return delta;
        return Math.round(delta / sensitivity) * sensitivity;
    }

    private static float calcGcd(float a, float b) {
        return b < 0.001f ? a : calcGcd(b, a % b);
    }

    private static float jitter(long tick, float amount, float freq) {
        double wave = Math.sin(tick * freq) * 0.6 + RNG.nextGaussian() * 0.4;
        return (float)(wave * amount);
    }

    private static boolean aimClose(float tYaw, float tPitch) {
        float dy = Math.abs(MathHelper.wrapDegrees(silentYaw - tYaw));
        float dp = Math.abs(silentPitch - tPitch);
        return dy < 4f && dp < 4f;
    }

    private static float targetYaw(MinecraftClient mc, LivingEntity target) {
        Vec3d diff = target.getBoundingBox().getCenter().subtract(mc.player.getEyePos());
        return (float) Math.toDegrees(Math.atan2(-diff.x, diff.z));
    }

    private static float targetPitch(MinecraftClient mc, LivingEntity target) {
        Vec3d diff = target.getBoundingBox().getCenter().subtract(mc.player.getEyePos());
        return (float) -Math.toDegrees(
                Math.atan2(diff.y, Math.sqrt(diff.x * diff.x + diff.z * diff.z)));
    }
}
