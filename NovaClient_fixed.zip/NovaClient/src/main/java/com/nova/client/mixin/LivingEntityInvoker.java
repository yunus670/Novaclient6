package com.nova.client.mixin;

import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/** Lets the client call the (protected) vanilla jump, used by Jump Reset. */
@Mixin(LivingEntity.class)
public interface LivingEntityInvoker {
    @Invoker("jump")
    void nova$invokeJump();
}
