package com.nova.client.module;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.math.Vec3d;

public abstract class Module {
    private final String name;
    private final String description;
    private final Category category;
    private boolean toggled;
    private final BindSetting keybind = new BindSetting("Keybind", 0);
    private List<Object> settings;

    protected Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    public String getName() { return name; }
    public String getDescription() { return description; }
    public Category getCategory() { return category; }
    public boolean isToggled() { return toggled; }
    public void setToggled(boolean toggled) {
        if (this.toggled == toggled) return;
        this.toggled = toggled;
        if (toggled) onEnable(); else onDisable();
    }
    public void toggle() { setToggled(!this.toggled); }
    /** Changes the state without calling onEnable/onDisable (used when the GUI itself closed). */
    public void forceToggled(boolean toggled) { this.toggled = toggled; }

    /** All Number/Mode/Boolean settings of this module, in the order they are declared. */
    public List<Object> getSettings() {
        if (settings == null) {
            settings = new ArrayList<>();
            if (hasKeybind()) settings.add(keybind);
            for (Field f : getClass().getDeclaredFields()) {
                Class<?> t = f.getType();
                if (t == NumberSetting.class || t == ModeSetting.class || t == BooleanSetting.class || t == BindSetting.class) {
                    try {
                        f.setAccessible(true);
                        settings.add(f.get(this));
                    } catch (IllegalAccessException ignored) { }
                }
            }
        }
        return settings;
    }
    public int getKey() { return keybind.getKey(); }
    public void setKey(int key) { keybind.setKey(key); }
    public BindSetting getKeybind() { return keybind; }
    /** False for modules that must not get a toggle key (ClickGui has its own key binding). */
    public boolean hasKeybind() { return true; }
    public void onTick() { }
    /** World-space rendering. Vertices must be written relative to camPos. */
    public void onRender3D(MatrixStack matrices, Vec3d camPos, float tickProgress) { }
    /** Screen-space rendering (HUD). */
    public void onRender2D(DrawContext context) { }
    public void onEnable() { }
    public void onDisable() { }
}
