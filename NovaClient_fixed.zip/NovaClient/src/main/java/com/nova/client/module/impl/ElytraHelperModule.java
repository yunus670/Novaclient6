package com.nova.client.module.impl;

import com.nova.client.input.KeyEvents;
import com.nova.client.module.BindSetting;
import com.nova.client.module.Category;
import com.nova.client.module.Module;
import com.nova.client.module.NumberSetting;
import com.nova.client.rotation.RotationManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;

/**
 * Press the assigned key while gliding: a firework rocket from the hotbar is used silently.
 * The rocket is taken for a moment and the slot you were holding (sword...) is selected again
 * right away, so Aura keeps hitting with the right item.
 */
public final class ElytraHelperModule extends Module {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    public final BindSetting fireworkKey = new BindSetting("Firework Key", 0);
    /** Minimum ticks between two rockets, so holding the key does not spam. */
    public final NumberSetting cooldown = new NumberSetting("Cooldown (ticks)", 4.0, 0.0, 20.0, 1.0);

    private boolean wasDown;
    private int cooldownTicks;

    public ElytraHelperModule() {
        super("ElytraHelper", "Silent firework use on a key.", Category.MISC);
    }

    @Override public void onEnable() { wasDown = false; cooldownTicks = 0; }

    @Override
    public void onTick() {
        if (mc.player == null || mc.interactionManager == null) return;
        if (cooldownTicks > 0) cooldownTicks--;

        int key = fireworkKey.getKey();
        if (key == 0) return;

        boolean down = false;
        try {
            down = InputUtil.isKeyPressed(mc.getWindow().getHandle(), key);
        } catch (Throwable ignored) { }
        boolean pressed = (down && !wasDown) | KeyEvents.consume(key); // key event OR fresh press seen by polling
        wasDown = down;

        if (!pressed || mc.currentScreen != null || cooldownTicks > 0) return;
        if (useFirework()) cooldownTicks = (int) cooldown.getValue();
    }

    private boolean useFirework() {
        var inv = mc.player.getInventory();

        // Already in a hand: no swap needed.
        if (mc.player.getOffHandStack().isOf(Items.FIREWORK_ROCKET)) return use(Hand.OFF_HAND);
        if (mc.player.getMainHandStack().isOf(Items.FIREWORK_ROCKET)) return use(Hand.MAIN_HAND);

        int slot = -1;
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).isOf(Items.FIREWORK_ROCKET)) { slot = i; break; }
        }
        if (slot == -1) return false;

        int original = inv.selectedSlot;
        inv.selectedSlot = slot;          // interactItem syncs this slot to the server first
        boolean used = use(Hand.MAIN_HAND);
        inv.selectedSlot = original;      // swapped back; the server hears it at the start of the next tick
        return used;
    }

    private boolean use(Hand hand) {
        // The use packet carries yaw/pitch: while Aura's silent rotation is active, send that one
        // so the server does not see two different looks in the same tick.
        float yaw = mc.player.getYaw();
        float pitch = mc.player.getPitch();
        if (RotationManager.isActive()) {
            mc.player.setYaw(RotationManager.getYaw());
            mc.player.setPitch(RotationManager.getPitch());
        }
        ActionResult result = mc.interactionManager.interactItem(mc.player, hand);
        mc.player.setYaw(yaw);
        mc.player.setPitch(pitch);

        if (result.isAccepted()) {
            mc.player.swingHand(hand);
            return true;
        }
        return false;
    }
}
