package com.nova.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.BufferBuilder;
import org.joml.Matrix4f;

public final class Draw2D {
    private Draw2D() { }

    public static void roundedRect(DrawContext ctx, float x1, float y1, float x2, float y2, float radius, int color) {
        if (x2 <= x1 || y2 <= y1 || ((color >>> 24) & 255) == 0) return;
        float r = Math.max(0f, Math.min(radius, Math.min((x2 - x1) / 2f, (y2 - y1) / 2f)));
        ctx.draw();
        Matrix4f m = ctx.getMatrices().peek().getPositionMatrix();
        beginColor();
        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        if (r < 0.5f) {
            quad(buf, m, x1, y1, x2, y2, color);
        } else {
            int rows = Math.max(3, (int) Math.ceil(r * scale()));
            float step = r / rows;
            quad(buf, m, x1, y1 + r, x2, y2 - r, color);
            for (int i = 0; i < rows; i++) {
                float dy = r - (i + 0.5f) * step;
                float inset = r - (float) Math.sqrt(Math.max(0f, r * r - dy * dy));
                quad(buf, m, x1 + inset, y1 + i * step,       x2 - inset, y1 + (i + 1) * step, color);
                quad(buf, m, x1 + inset, y2 - (i + 1) * step, x2 - inset, y2 - i * step,       color);
            }
        }
        BufferRenderer.drawWithGlobalProgram(buf.endNullable());
        endColor();
        ctx.draw();
    }

    public static void circle(DrawContext ctx, float cx, float cy, float radius, int color) {
        if (radius <= 0f || ((color >>> 24) & 255) == 0) return;
        ctx.draw();
        Matrix4f m = ctx.getMatrices().peek().getPositionMatrix();
        beginColor();
        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        int rows = Math.max(8, (int) Math.ceil(radius * 2f * scale()));
        float step = radius * 2f / rows;
        for (int i = 0; i < rows; i++) {
            float y1 = cy - radius + i * step;
            float dy = y1 + step / 2f - cy;
            float half = (float) Math.sqrt(Math.max(0f, radius * radius - dy * dy));
            quad(buf, m, cx - half, y1, cx + half, y1 + step, color);
        }
        BufferRenderer.drawWithGlobalProgram(buf.endNullable());
        endColor();
        ctx.draw();
    }

    private static void beginColor() {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
    }

    private static void endColor() {
        RenderSystem.disableBlend();
    }

    private static float scale() {
        return (float) Math.max(1.0, MinecraftClient.getInstance().getWindow().getScaleFactor());
    }

    private static void quad(BufferBuilder buf, Matrix4f m,
                              float x1, float y1, float x2, float y2, int color) {
        if (x2 <= x1 || y2 <= y1) return;
        buf.vertex(m, x1, y1, 0f).color(color);
        buf.vertex(m, x1, y2, 0f).color(color);
        buf.vertex(m, x2, y2, 0f).color(color);
        buf.vertex(m, x2, y1, 0f).color(color);
    }
}
