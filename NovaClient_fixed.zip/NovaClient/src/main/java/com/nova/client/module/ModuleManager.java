package com.nova.client.module;

import com.nova.client.module.impl.AuraModule;
import com.nova.client.module.impl.ClickGuiModule;
import com.nova.client.module.impl.ElytraHelperModule;
import com.nova.client.module.impl.HudModule;
import com.nova.client.module.impl.KeyBindsModule;
import com.nova.client.module.impl.SpeedModule;
import com.nova.client.module.impl.TargetEspModule;
import com.nova.client.module.impl.TargetHudModule;
import com.nova.client.module.impl.VelocityModule;
import com.nova.client.input.KeyEvents;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class ModuleManager {
    private static final List<Module> modules = new ArrayList<>();
    private static final Map<Integer, Boolean> keyStates = new HashMap<>();
    private static boolean initialized;

    private ModuleManager() { }

    public static void init() {
        if (initialized) return;
        modules.clear();
        modules.add(new VelocityModule());
        modules.add(new ElytraHelperModule());
        modules.add(new SpeedModule());
        modules.add(new AuraModule());
        modules.add(new TargetEspModule());
        modules.add(new TargetHudModule());
        modules.add(new HudModule());
        modules.add(new KeyBindsModule());
        modules.add(new ClickGuiModule());
        initialized = true;
    }

    public static void onKeyPressed(int key) {
        if (key == 0) return;
        for (Module module : modules) {
            if (module.getKey() == key) module.toggle();
        }
    }

    public static void handleKeybinds(MinecraftClient client) {
        if (client == null || client.getWindow() == null) return;
        long handle = client.getWindow().getHandle();
        Set<Integer> handled = new HashSet<>();
        for (Module module : modules) {
            int key = module.getKey();
            if (key == 0 || !handled.add(key)) continue;
            boolean down;
            try {
                down = GLFW.glfwGetKey(handle, key) == GLFW.GLFW_PRESS;
            } catch (Throwable t) { // some launchers' GLFW layers do not implement every call
                down = false;
            }
            boolean wasDown = keyStates.getOrDefault(key, false);
            // No keybinds while any screen is open (chat, inventory, ClickGUI search...)
            // a fresh press seen by polling OR a key event (catches very short taps, e.g. touch buttons)
            boolean pressed = (down && !wasDown) | KeyEvents.peek(key);
            if (client.currentScreen == null && pressed) onKeyPressed(key);
            keyStates.put(key, down);
        }
    }

    public static <T extends Module> T get(Class<T> type) {
        for (Module module : modules) {
            if (type.isInstance(module)) return type.cast(module);
        }
        return null;
    }

    public static List<Module> getModules() { return List.copyOf(modules); }
}
